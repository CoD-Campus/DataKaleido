FILE_PATH=$(dirname $(readlink -f $0))
BASE_PATH=${FILE_PATH}
PACKAGE_PATH=${BASE_PATH}/packages

usage() {
    echo "
Usage: 
    $0 dk
    # $0 agent <agent-port>
"
    exit 1
}

ensure_clean() {
    echo "Are you sure to destory dk(yes/no):"
    read yes_or_no
    if [ "$yes_or_no" != "yes" ]; then
        echo "abort."
        exit 1
    fi
}

check_code() {
    ret=$1
    name=$2
    is_no_exit="$3"
    
    if [ $ret -ne 0 ]; then
        echo "[${name}] check code failed, ret=${ret}"
        if [[ "1"a == "$is_no_exit"a ]]; then
            return
        fi
        exit $ret
    fi
    return
}

get_tarfn(){
    name="$1"
    zipfn=$(ls ${PACKAGE_PATH}/${name} | head -n 1)
    if [ "$zipfn"a == ""a ]; then
        echo "${name} zip package unfound"
        exit 1
    fi
    echo "$zipfn"
    return 0
}

stop_dk() {
    cd ${BASE_PATH}/scripts
    bash cod-dk.sh forcestop
    check_code "$?" "stop cod-dk"
    return 0
}

stop_monit() {
    ${BASE_PATH}/monit/monitctl stop
    check_code "$?" "stop monit"
    return 0
}

clean_all() {
    is_stop_agent="$1"
    if [ -f ${BASE_PATH}/monit/monitctl ]; then
        stop_monit
    fi
    if [ -d ${BASE_PATH}/scripts ]; then
        stop_dk
    fi
    rm -rf ${BASE_PATH}/node_exporter*
    rm -rf ${BASE_PATH}/prometheus*
    rm -rf ${BASE_PATH}/monit*
    rm -rf ${BASE_PATH}/yascheck*
    rm -rf ${BASE_PATH}/installation_resource
    rm -rf ${BASE_PATH}/bin
    rm -rf ${BASE_PATH}/data
    rm -rf ${BASE_PATH}/etc
    rm -rf ${BASE_PATH}/log
    rm -rf ${BASE_PATH}/log_backup 
    rm -rf ${BASE_PATH}/scripts
    rm -rf ${BASE_PATH}/static
    echo "清理已完成"
    return 0
}

if [ "$1" == "--yes-i-am-sure" ]; then
    echo "'--yes-i-am-sure' be got, cleaning..."
else
    ensure_clean
fi
clean_all "$2"
