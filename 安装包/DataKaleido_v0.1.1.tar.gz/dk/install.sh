VERSION=""
FILE_PATH=$(dirname $(readlink -f $0))
BASE_PATH=${FILE_PATH}
PACKAGE_PATH=${BASE_PATH}/packages
CONFIG_PATH=${BASE_PATH}/etc
SCRIPTS_PATH=${BASE_PATH}/scripts
MONIT_INSTALLER=${BASE_PATH}/monit_installer

usage() {
    echo "
Usage:
    $0 dk <username>
"
    exit 1
}

check_code() {
    ret=$1
    name=$2
    is_no_exit="$3"

    if [ $ret -ne 0 ]; then
        echo "[${name}] check code failed, ret=${ret}"
        if [[ "1"a == "$is_no_exit"a ]]; then
            return
        fi
        exit $ret
    fi
    return
}

get_tarfn() {
    name="$1"
    pkg_path="$2"
    if [ "$pkg_path"a == ""a ]; then
        pkg_path="${PACKAGE_PATH}"
    fi
    zipfn=$(ls ${pkg_path}/${name} | head -n 1)
    if [ "$zipfn"a == ""a ]; then
        echo "${name} zip package unfound"
        exit 1
    fi
    echo "$zipfn"
    return 0
}

unzip() {
    tarfn="$1"
    dest_dir="$2"
    if [ "$dest_dir"a == ""a ]; then
        dest_dir="${BASE_PATH}"
    fi
    if [[ ! -f "$tarfn" ]]; then
        echo "$tarfn is not exist."
        return 1
    fi
    echo "unziping ${tarfn}"
    tar -xzvf ${tarfn} -C ${dest_dir} >/dev/null 2>&1
    ret=$?
    if [ $ret -ne 0 ]; then
        echo "unzip ${tarfn} failed"
        return ret
    fi
    echo "unzip ${tarfn} success"
    return 0
}

unzip_dk() {
    echo "unzip dk starting"
    cd ${BASE_PATH}
    tarfn=$(get_tarfn "dk-${VERSION}.tar.gz")
    unzip ${tarfn}
    check_code "$?" "unzip ${tarfn}"
    chmod +x ${BASE_PATH}/scripts/*
    return 0
}

unzip_dg() {
    echo "unzip dg starting"
    cd ${BASE_PATH}
    tarfn=$(get_tarfn "dg-${VERSION}.tar.gz")
    unzip ${tarfn} ${BASE_PATH}/  #static/
    check_code "$?" "unzip ${tarfn}"
    # chmod +x ${BASE_PATH}/scripts/*
    return 0
}

unzip_dkweb() {
    echo "unzip dkweb starting"
    cd ${BASE_PATH}
    tarfn=$(get_tarfn "dkweb-${VERSION}.tar.gz")
    unzip ${tarfn} ${BASE_PATH}/static
    check_code "$?" "unzip ${tarfn}"
    return 0
}


unzip_monit() {
    echo "unzip monit starting"
    cd ${BASE_PATH}
    mkdir ${MONIT_INSTALLER}
    tarfn=$(get_tarfn "monit-5.29.0*.tar.gz")
    unzip ${tarfn} ${MONIT_INSTALLER}
    check_code "$?" "unzip ${tarfn}"
    echo "copy prometheus config"
    return 0
}

init_monit() {
    username=$1
    if [ "$username"a == ""a ]; then
        username=$USER
    fi
    cd ${MONIT_INSTALLER}
    sudo ./init.sh -p ${BASE_PATH} -u ${username}
    check_code "$?" "init monit"
    cd ${BASE_PATH} 
    rm -rf ${MONIT_INSTALLER}
}

generate_monit_conf() {
    name=$1
    process_name=""
    if [[ $name == cod-* ]]; then
        process_name=${BASE_PATH}/bin/${name}
    elif [[ $name == prometheus* ]]; then
        process_name=${BASE_PATH}/prometheus-2.28.1.linux-amd64/${name}
    elif [[ $name == node* ]]; then
        process_name=${BASE_PATH}/node_exporter-1.2.2/${name}
        name=node-exporter
    fi
    MONIT_PATH=${BASE_PATH}/monit
    echo "
    check program hold-${name}
        with path \"${MONIT_PATH}/bin/monit -c ${MONIT_PATH}/data/monitrc monitor ${name}\" with timeout 10 seconds
        group ${name}
        if status != 0 then alert
        every 60 cycles
    check process ${name} with matching \"${process_name} \" 
        group ${name}
        start program = \"${BASE_PATH}/scripts/${name}.sh start\" with timeout 30 seconds
        stop program  = \"${BASE_PATH}/scripts/${name}.sh stop\"  with timeout 30 seconds
        if 3 restarts within 3 cycles then unmonitor
        " >${MONIT_PATH}/data/conf/${name}.conf
    ${MONIT_PATH}/monitctl reload
    return 0
}

install_domor() {
    username=$1
    unzip_dk
    unzip_dg
    unzip_dkweb
    unzip_monit
    init_monit ${username}
    chown -R "${username}:${username}" ${BASE_PATH}
    ${SCRIPTS_PATH}/cod-dk.sh start
    check_code "$?" "start dk"
    generate_monit_conf "cod-dk"
    return $?
}


case "$1" in
dk)
    if [ "$2" == "" ]; then
        usage
    fi
    install_domor $2
    ;;
*)
    usage
    ;;

esac